package concrete_dao;

import abs.DAOBase;
import implement_dao.MoviePrizeMapper;
import substance.MoviePrize;

public class MoviePrizeConcrete extends DAOBase implements MoviePrizeMapper {

	@Override
	public int deleteByPrimaryKey(String moviePrizeId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(MoviePrize record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public MoviePrize selectByPrimaryKey(String moviePrizeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(MoviePrize record) {
		// TODO Auto-generated method stub
		return 0;
	}
    
}