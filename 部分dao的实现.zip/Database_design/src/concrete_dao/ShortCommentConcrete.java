package concrete_dao;

import abs.DAOBase;
import implement_dao.ShortCommentMapper;
import substance.ShortComment;

public class ShortCommentConcrete extends DAOBase implements ShortCommentMapper {

	@Override
	public int deleteByPrimaryKey(String shortCommentId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(ShortComment record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ShortComment selectByPrimaryKey(String shortCommentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(ShortComment record) {
		// TODO Auto-generated method stub
		return 0;
	}
    
}