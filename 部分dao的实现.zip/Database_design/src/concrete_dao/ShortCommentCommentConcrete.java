package concrete_dao;

import abs.DAOBase;
import implement_dao.ShortCommentCommentMapper;
import substance.ShortCommentComment;

public class ShortCommentCommentConcrete extends DAOBase implements ShortCommentCommentMapper {

	@Override
	public int deleteByPrimaryKey(String shortCommendCommendId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(ShortCommentComment record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ShortCommentComment selectByPrimaryKey(String shortCommendCommendId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(ShortCommentComment record) {
		// TODO Auto-generated method stub
		return 0;
	}
    
}