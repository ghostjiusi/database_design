package concrete_dao;

import abs.DAOBase;
import implement_dao.MovieDirectorMapper;
import substance.MovieDirectorKey;

public class MovieDirectorConcrete extends DAOBase implements MovieDirectorMapper {

	@Override
	public int deleteByPrimaryKey(MovieDirectorKey key) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(MovieDirectorKey record) {
		// TODO Auto-generated method stub
		return 0;
	}

}