package abs;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
/*
 * 具体的连接在这里执行
 */
public class DAOBase implements DAO{
    @Override
    public Connection getConnection() {
        Connection conn=null;
        try{
            //这里new一个conn对象，然后使用conn对象的方法来进行数据库的连接操作
        } catch (Exception e){
            e.printStackTrace();
        }
        return conn;
    }

    @Override
    public void closeConnection(Connection conn, Statement stmt, ResultSet rs ) {
        
    	//这里new一个conn对象，然后使用conn对象的方来来进行数据库的关闭
    }
}
