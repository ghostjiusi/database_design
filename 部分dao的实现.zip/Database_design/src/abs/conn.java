package abs;

import java.sql.*;

public class conn {
    public static Connection getConnection() throws SQLException {
		return null;
        //这里进行具体数据库的连接
    }
    public static void release(Connection conn, Statement stmt, ResultSet rs ){
        if(conn!=null){
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(stmt!=null){
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(rs!=null){
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }
}