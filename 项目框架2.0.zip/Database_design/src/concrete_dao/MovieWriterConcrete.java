package concrete_dao;

import abs.DAOBase;
import implement_dao.MovieWriterMapper;
import substance.MovieWriterKey;

public class MovieWriterConcrete extends DAOBase implements MovieWriterMapper {

	@Override
	public int deleteByPrimaryKey(MovieWriterKey key) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(MovieWriterKey record) {
		// TODO Auto-generated method stub
		return 0;
	}
    
}