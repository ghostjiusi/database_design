package concrete_dao;

import abs.DAOBase;
import implement_dao.TagMapper;
import substance.Tag;

public class TagConcrete extends DAOBase implements TagMapper {

	@Override
	public int deleteByPrimaryKey(String tagId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(Tag record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Tag selectByPrimaryKey(String tagId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(Tag record) {
		// TODO Auto-generated method stub
		return 0;
	}
    
}