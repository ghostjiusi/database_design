package concrete_dao;

import abs.DAOBase;
import implement_dao.MovieMapper;
import substance.Movie;

public class MovieConcrete extends DAOBase implements MovieMapper {

	@Override
	public int deleteByPrimaryKey(String movieId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(Movie record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Movie selectByPrimaryKey(String movieId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(Movie record) {
		// TODO Auto-generated method stub
		return 0;
	}

}