package concrete_dao;



import abs.DAOBase;
import implement_dao.MovieActorMapper;
import substance.MovieActorKey;

public class MovieActorConcrete extends DAOBase implements MovieActorMapper {

	@Override
	public int deleteByPrimaryKey(MovieActorKey key) {
		return 0;
		
	}

	@Override
	public int insert(MovieActorKey record) {
		// TODO Auto-generated method stub
		return 0;
	}
   
}