package concrete_dao;

import abs.DAOBase;
import implement_dao.LongCommentCommentMapper;
import substance.LongCommentComment;

public class LongCommentCommentConcrete extends DAOBase implements LongCommentCommentMapper {

	@Override
	public int deleteByPrimaryKey(String longCommentCommentId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(LongCommentComment record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public LongCommentComment selectByPrimaryKey(String longCommentCommentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(LongCommentComment record) {
		// TODO Auto-generated method stub
		return 0;
	}
    
}