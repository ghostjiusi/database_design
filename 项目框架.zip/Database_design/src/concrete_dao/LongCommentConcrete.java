package concrete_dao;

import abs.DAOBase;
import implement_dao.LongCommentMapper;
import substance.LongComment;

public class LongCommentConcrete extends DAOBase implements LongCommentMapper {

	@Override
	public int deleteByPrimaryKey(String longCommentId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(LongComment record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public LongComment selectByPrimaryKey(String longCommentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(LongComment record) {
		// TODO Auto-generated method stub
		return 0;
	}
   
}