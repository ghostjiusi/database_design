package concrete_dao;

import abs.DAOBase;
import implement_dao.WriterMapper;
import substance.WriterKey;

public class WriterConcrete extends DAOBase implements WriterMapper {

	@Override
	public int deleteByPrimaryKey(WriterKey key) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(WriterKey record) {
		// TODO Auto-generated method stub
		return 0;
	}
    
}