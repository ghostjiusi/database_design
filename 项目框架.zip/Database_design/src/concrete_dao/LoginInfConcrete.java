package concrete_dao;

import abs.DAOBase;
import implement_dao.LoginInfMapper;
import substance.LoginInf;

public class LoginInfConcrete extends DAOBase implements LoginInfMapper {

	@Override
	public int deleteByPrimaryKey(String userId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(LoginInf record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public LoginInf selectByPrimaryKey(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(LoginInf record) {
		// TODO Auto-generated method stub
		return 0;
	}
    
}