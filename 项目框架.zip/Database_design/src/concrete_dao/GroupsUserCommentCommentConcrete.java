package concrete_dao;

import abs.DAOBase;
import implement_dao.GroupsUserCommentCommentMapper;
import substance.GroupsUserCommentComment;

public class GroupsUserCommentCommentConcrete extends DAOBase implements GroupsUserCommentCommentMapper {

	@Override
	public int deleteByPrimaryKey(String groupsCommentCommentId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(GroupsUserCommentComment record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public GroupsUserCommentComment selectByPrimaryKey(String groupsCommentCommentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(GroupsUserCommentComment record) {
		// TODO Auto-generated method stub
		return 0;
	}
}