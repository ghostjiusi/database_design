package concrete_dao;

import abs.DAOBase;
import implement_dao.GroupsUserCommentMapper;
import substance.GroupsUserComment;

public class GroupsUserCommentConcrete extends DAOBase implements GroupsUserCommentMapper {

	@Override
	public int deleteByPrimaryKey(String groupsCommentId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(GroupsUserComment record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public GroupsUserComment selectByPrimaryKey(String groupsCommentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(GroupsUserComment record) {
		// TODO Auto-generated method stub
		return 0;
	}
    
}