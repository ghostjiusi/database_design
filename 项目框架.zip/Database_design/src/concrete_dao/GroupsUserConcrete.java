package concrete_dao;

import abs.DAOBase;
import implement_dao.GroupsUserMapper;
import substance.GroupsUser;

public class GroupsUserConcrete extends DAOBase implements GroupsUserMapper {

	@Override
	public int deleteByPrimaryKey(String groupsUserId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(GroupsUser record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public GroupsUser selectByPrimaryKey(String groupsUserId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(GroupsUser record) {
		// TODO Auto-generated method stub
		return 0;
	}
    
}