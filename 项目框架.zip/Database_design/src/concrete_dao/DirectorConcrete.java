package concrete_dao;

import abs.DAOBase;
import implement_dao.ActorPrizeMapper;
import substance.ActorPrize;

public class DirectorConcrete extends DAOBase implements ActorPrizeMapper{

	@Override
	public int deleteByPrimaryKey(String actorPrizeId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(ActorPrize record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ActorPrize selectByPrimaryKey(String actorPrizeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKey(ActorPrize record) {
		// TODO Auto-generated method stub
		return 0;
	}
}