package concrete_dao;

import abs.DAOBase;
import implement_dao.MovieTagMapper;
import substance.MovieTagKey;

public class MovieTagConcrete extends DAOBase implements MovieTagMapper {

	@Override
	public int deleteByPrimaryKey(MovieTagKey key) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(MovieTagKey record) {
		// TODO Auto-generated method stub
		return 0;
	}
    
}