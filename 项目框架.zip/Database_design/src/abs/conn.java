package abs;

public class conn {

}
